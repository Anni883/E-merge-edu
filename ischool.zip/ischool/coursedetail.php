<?php
include('./maininclude/header.php');
?>

<div class="container-fluid bg-dark">
    <div class="row">
        <img src="./image/payment1.png" alt="courses"
        style="height:500px; width:200%; object-fit:cover;
        box-shadow:10px;"/>
        </div>
</div>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <img src="./image/courseimg/guitar.jpg" class="card-img-top"
            alt="Guitar" />
</div>
<div class="col-md-8">
    <div class="card-body">
        <h5 class="card-title">Course Name: Learn Guitar</h5>
        <p class="card-text">Description:Be master in guiter learning just in few weeks and showoff your skill.</p>
        <p class="card-text"> Duration:1 month</p>
        <form action=" " method="post">
            <p class="card-text d-inline">Price: <small><del>&#83577 2000</del></small> <span class="font-weight-bolder">&#83577 200<span></p>
            <button type="submit" class="btn btn-primary text-white font-weight-bolder float-right" name="buy">Buy Now</button>
</form>
</div>
</div>
</div>

<div class="container">

<div class="row">
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th scope="col">Lesson No.</th>
                <th scope="col">Lesson Name</th>
</tr>
</thead>
<tbody>
    <tr>
        <th scope="row">1</th>
        <td>Introduction</td></tr>';
</tobody>
</table>';
</div>
</div>






<?php
include('./maininclude/footer.php');
?>