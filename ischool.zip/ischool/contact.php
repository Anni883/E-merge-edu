<div class="container mt-4" id="Contact">
    <h2 class="text-center mb-4">Contact US</h2>
    <div class="row">
      <div class="col-md-8">
        <form action=""method="post">
          <input type="text" class="form-control" name="name" 
          placeholder="Name"><br>
          <input type="text" class="form-control" name="subject"
          placeholder="Subject"><br>
          <input type="text" class="form-control" name="email"
          placeholder="Email"><br>
          <textarea class="form-control" name="message"
          placeholder="How can i help you?" style="height:150px;
          "></textarea><br>
          <input class="btn btn-primary" type="submit"
          value="Send" name="submit"><br><br>
  </form>
  </div>
  
  <div class="col-md-4 stripe text-white text-center">
    <h4>E-MERGE EDUCATION</h4>
    <p>E-MERGE EDUCATION,
      Near Banani RD 8,Dhaka,
      Bangladesh-834005<br />
      Phone:000567865<br />
      www.e-mergeeducation.com</p>
      </div>
  </div>
  </div>